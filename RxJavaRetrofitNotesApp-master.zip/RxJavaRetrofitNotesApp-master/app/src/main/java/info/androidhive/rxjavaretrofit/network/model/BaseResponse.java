package info.androidhive.rxjavaretrofit.network.model;

/**
 * Created by ravi on 21/02/18.
 */

public class BaseResponse {
    String error;

    public String getError() {
        return error;
    }
}
